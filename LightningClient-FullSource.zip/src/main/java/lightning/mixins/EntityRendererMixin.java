/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lightning.Night
 *  lightning.modules.impl.visuals.ChamsModule
 *  lightning.modules.impl.visuals.LogoutSpotModule
 *  lightning.modules.impl.visuals.NameTagsModule
 *  lightning.modules.impl.visuals.NoRenderModule
 *  lightning.modules.impl.visuals.PopChamsModule
 *  lightning.modules.impl.visuals.ShadersModule
 *  net.minecraft.client.player.RemotePlayer
 *  net.minecraft.client.renderer.culling.Frustum
 *  net.minecraft.client.renderer.entity.EntityRenderer
 *  net.minecraft.client.renderer.entity.state.EntityRenderState
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.entity.Display
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.boss.enderdragon.EndCrystal
 *  net.minecraft.world.entity.decoration.ArmorStand
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.entity.vehicle.boat.AbstractBoat
 *  net.minecraft.world.entity.vehicle.minecart.AbstractMinecart
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package lightning.mixins;

import lightning.Night;
import lightning.modules.impl.visuals.ChamsModule;
import lightning.modules.impl.visuals.LogoutSpotModule;
import lightning.modules.impl.visuals.NameTagsModule;
import lightning.modules.impl.visuals.NoRenderModule;
import lightning.modules.impl.visuals.PopChamsModule;
import lightning.modules.impl.visuals.ShadersModule;
import lightning.utils.mixins.IChamsCapture;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={EntityRenderer.class})
public class EntityRendererMixin<T extends Entity, S extends EntityRenderState> {
    @Inject(method={"getNameTag"}, at={@At(value="HEAD")}, cancellable=true)
    private void getDisplayName(T t, CallbackInfoReturnable<Component> callbackInfoReturnable) {
        try {
            if (t instanceof RemotePlayer) {
                RemotePlayer remotePlayer = (RemotePlayer)t;
                PopChamsModule popChamsModule = (PopChamsModule)Night.MODULE_MANAGER.getModule(PopChamsModule.class);
                if (popChamsModule != null && popChamsModule.isToggled() && popChamsModule.isGhost((Entity)remotePlayer)) {
                    callbackInfoReturnable.setReturnValue(null);
                    return;
                }
                LogoutSpotModule logoutSpotModule = (LogoutSpotModule)Night.MODULE_MANAGER.getModule(LogoutSpotModule.class);
                if (logoutSpotModule != null && logoutSpotModule.isToggled() && logoutSpotModule.isGhost((Entity)remotePlayer)) {
                    callbackInfoReturnable.setReturnValue(null);
                    return;
                }
            }
            if (t instanceof Player && ((NameTagsModule)Night.MODULE_MANAGER.getModule(NameTagsModule.class)).isToggled()) {
                callbackInfoReturnable.setReturnValue(null);
            }
            return;
        }
        catch (NullPointerException nullPointerException) {
            return;
        }
    }

    @Inject(method={"shouldRender"}, at={@At(value="HEAD")}, cancellable=true)
    private void night$limitItemRendering(T t, Frustum frustum, double d, double d2, double d3, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        try {
            NoRenderModule noRenderModule;
            if (t instanceof RemotePlayer) {
                RemotePlayer remotePlayer = (RemotePlayer)t;
                noRenderModule = Night.MODULE_MANAGER != null ? (PopChamsModule)Night.MODULE_MANAGER.getModule(PopChamsModule.class) : null;
                PopChamsModule popChamsModule = noRenderModule;
                if (noRenderModule != null && noRenderModule.isToggled() && noRenderModule.isGhost((Entity)remotePlayer)) {
                    callbackInfoReturnable.setReturnValue((Object)true);
                    return;
                }
            }
            NoRenderModule noRenderModule2 = Night.MODULE_MANAGER != null ? (NoRenderModule)Night.MODULE_MANAGER.getModule(NoRenderModule.class) : null;
            noRenderModule = noRenderModule2;
            if (noRenderModule2 != null && noRenderModule2.isToggled()) {
                if (noRenderModule2.items.getValue() && t instanceof ItemEntity && !noRenderModule2.shouldRenderItem()) {
                    callbackInfoReturnable.setReturnValue((Object)false);
                }
                if (noRenderModule2.displays.getValue() && t instanceof Display) {
                    callbackInfoReturnable.setReturnValue((Object)false);
                }
                if (noRenderModule2.armorStand.getValue() && t instanceof ArmorStand) {
                    callbackInfoReturnable.setReturnValue((Object)false);
                }
                if (noRenderModule2.minecart.getValue() && t instanceof AbstractMinecart) {
                    callbackInfoReturnable.setReturnValue((Object)false);
                }
            }
            return;
        }
        catch (NullPointerException nullPointerException) {
            return;
        }
    }

    /*
     * Unable to fully structure code
     */
    @Inject(method={"extractRenderState"}, at={@At(value="TAIL")})
    private void night$chams(T var1_1, S var2_2, float var3_3, CallbackInfo var4_4) {
        try {
            var5_5 = (IChamsCapture)var2_2;
            var5_5.night$setChams(false, 0, false, 0, false);
            var5_5.night$setChamsYOffset(0.0f);
            var6_6 = (PopChamsModule)Night.MODULE_MANAGER.getModule(PopChamsModule.class);
            var7_7 = (LogoutSpotModule)Night.MODULE_MANAGER.getModule(LogoutSpotModule.class);
            if (!(var1_1 instanceof RemotePlayer)) ** GOTO lbl-1000
            var9_8 = (RemotePlayer)var1_1;
            if (var6_6 != null && var6_6.isGhost((Entity)var9_8)) {
                v0 = true;
            } else lbl-1000:
            // 2 sources

            {
                v0 = var8_10 = false;
            }
            if (!(var1_1 instanceof RemotePlayer)) ** GOTO lbl-1000
            var10_11 = (RemotePlayer)var1_1;
            if (var7_7 != null && var7_7.isGhost((Entity)var10_11)) {
                v1 = true;
            } else lbl-1000:
            // 2 sources

            {
                v1 = false;
            }
            var9_9 = v1;
            v2 = var10_12 = var8_10 != false || var9_9 != false;
            if (!var10_12) {
                var11_13 = (ChamsModule)Night.MODULE_MANAGER.getModule(ChamsModule.class);
                if (var11_13.isToggled()) {
                    if (var1_1 instanceof LivingEntity && var11_13.isValidEntity((Entity)(var12_14 = (LivingEntity)var1_1))) {
                        var11_13.applyEntityChams((LivingEntity)var12_14, var5_5);
                    } else if (var11_13.crystals.getValue() && var1_1 instanceof EndCrystal && var11_13.inRange(var1_1)) {
                        var11_13.applyCrystalChams(var5_5);
                    } else if (var11_13.vehicles.getValue() && var11_13.inRange(var1_1) && (var1_1 instanceof AbstractBoat || var1_1 instanceof AbstractMinecart)) {
                        var11_13.applyVehicleChams(var5_5);
                    }
                }
                if ((var12_14 = (ShadersModule)Night.MODULE_MANAGER.getModule(ShadersModule.class)).isToggled() && var12_14.isValidEntity(var1_1)) {
                    var2_2.outlineColor = var12_14.getFillColor(var1_1);
                }
            }
            if (var6_6 != null && var6_6.isToggled() && var8_10) {
                var11_13 = (RemotePlayer)var1_1;
                var5_5.night$setChams(var6_6.shouldFill(), var6_6.getFillColor((RemotePlayer)var11_13).getRGB(), var6_6.shouldOutline(), var6_6.getOutlineColor((RemotePlayer)var11_13).getRGB(), false, true);
                var5_5.night$setChamsYOffset(var6_6.getYOffset((RemotePlayer)var11_13));
            }
            if (var7_7 != null && var7_7.isToggled() && var9_9) {
                var11_13 = (RemotePlayer)var1_1;
                var5_5.night$setChams(var7_7.shouldFill(), var7_7.getFillColor((RemotePlayer)var11_13).getRGB(), var7_7.shouldOutline(), var7_7.getOutlineColor((RemotePlayer)var11_13).getRGB(), false, true);
            }
            return;
        }
        catch (NullPointerException v3) {
            return;
        }
    }
}

