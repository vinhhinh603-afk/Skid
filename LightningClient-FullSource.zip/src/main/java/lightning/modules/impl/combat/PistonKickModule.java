/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Direction$Axis
 *  net.minecraft.core.Direction$Plane
 *  net.minecraft.core.Vec3i
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ServerboundAttackPacket
 *  net.minecraft.network.protocol.game.ServerboundSwingPacket
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.boss.enderdragon.EndCrystal
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.block.BannerBlock
 *  net.minecraft.world.level.block.BaseRailBlock
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.level.block.ButtonBlock
 *  net.minecraft.world.level.block.CarpetBlock
 *  net.minecraft.world.level.block.FlowerBlock
 *  net.minecraft.world.level.block.FlowerPotBlock
 *  net.minecraft.world.level.block.LadderBlock
 *  net.minecraft.world.level.block.LeverBlock
 *  net.minecraft.world.level.block.MushroomBlock
 *  net.minecraft.world.level.block.PressurePlateBlock
 *  net.minecraft.world.level.block.ScaffoldingBlock
 *  net.minecraft.world.level.block.SignBlock
 *  net.minecraft.world.level.block.TallFlowerBlock
 *  net.minecraft.world.level.block.TorchBlock
 *  net.minecraft.world.level.block.TripWireBlock
 *  net.minecraft.world.level.block.TripWireHookBlock
 *  net.minecraft.world.level.block.VineBlock
 *  net.minecraft.world.level.block.WebBlock
 *  net.minecraft.world.level.block.piston.PistonBaseBlock
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.properties.Property
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 */
package lightning.modules.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import lightning.Night;
import lightning.events.SubscribeEvent;
import lightning.events.impl.TickEvent;
import lightning.modules.Module;
import lightning.modules.RegisterModule;
import lightning.settings.impl.BooleanSetting;
import lightning.settings.impl.ModeSetting;
import lightning.settings.impl.NumberSetting;
import lightning.utils.minecraft.DamageUtils;
import lightning.utils.minecraft.EntityUtils;
import lightning.utils.minecraft.InventoryUtils;
import lightning.utils.minecraft.PistonHelper;
import lightning.utils.minecraft.WorldUtils;
import lightning.utils.miscellaneous.RenderPosition;
import lightning.utils.rotations.RotationUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.MushroomBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.ScaffoldingBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.TallFlowerBlock;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.TripWireBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.WebBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

@RegisterModule(name="PistonKick", description="Pushes players out of holes or solid blocks using pistons.", category=Module.Category.COMBAT)
public final class PistonKickModule
extends Module {
    public static PistonKickModule INSTANCE;
    public NumberSetting delay = new NumberSetting("Delay", "Delay between pushes (ticks)", 1, 0, 10);
    public NumberSetting pushDelay = new NumberSetting("PushDelay", "Duration to hold piston extended before retracting (ms)", 150, 50, 500);
    public ModeSetting power = new ModeSetting("Power", "How the piston is powered.", "Redstone", new String[]{"Redstone", "Lever"});
    public BooleanSetting airPlace = new BooleanSetting("AirPlace", "Allow placing when not on ground.", false);
    public BooleanSetting oneTwelve = new BooleanSetting("1.12", "Place piston and power in the same tick.", true);
    public NumberSetting targetRange = new NumberSetting("TargetRange", "Target range.", Float.valueOf(5.0f), Float.valueOf(1.0f), Float.valueOf(6.0f));
    public BooleanSetting inAirTarget = new BooleanSetting("InAirTarget", "Target players in the air.", true);
    public ModeSetting rotate = new ModeSetting("Rotate", "Silently rotate when placing.", "Silent", new String[]{"None", "Normal", "Silent"});
    public BooleanSetting breakCrystal = new BooleanSetting("BreakCrystal", "Break end crystals blocking piston path.", false);
    public NumberSetting placeRange = new NumberSetting("PlaceRange", "Block place range.", Float.valueOf(5.0f), Float.valueOf(1.0f), Float.valueOf(6.0f));
    public NumberSetting breakRange = new NumberSetting("BreakRange", "Crystal break range.", new BooleanSetting.Visibility(this.breakCrystal, true), (Number)Float.valueOf(4.5f), (Number)Float.valueOf(1.0f), (Number)Float.valueOf(6.0f));
    public NumberSetting maxLocalDamage = new NumberSetting("MaxLocalDamage", "Max self-damage allowed to break a crystal.", new BooleanSetting.Visibility(this.breakCrystal, true), (Number)Float.valueOf(8.0f), (Number)Float.valueOf(0.0f), (Number)Float.valueOf(20.0f));
    public BooleanSetting safety = new BooleanSetting("Safety", "Never break a crystal that would kill you.", new BooleanSetting.Visibility(this.breakCrystal, true), true);
    public ModeSetting swapAction = new ModeSetting("Swap", "How to swap to required items.", "Silent", InventoryUtils.SWITCH_MODES);
    public BooleanSetting consecutive = new BooleanSetting("Consecutive", "Keep targeting the same player consecutively.", true);
    public BooleanSetting merge = new BooleanSetting("Merge", "Burst piston and power packets together.", false);
    public BooleanSetting pauseOnEat = new BooleanSetting("PauseOnEat", "Pause while eating or using items.", false);
    public BooleanSetting strictDirection = new BooleanSetting("StrictDirection", "Use raytrace to verify line-of-sight before placing piston/redstone (required on servers that check raytrace).", false);
    public BooleanSetting render = new BooleanSetting("Render", "Render placed blocks using RendersModule.", true);
    private BlockPos targetPhasedPos;
    private BlockPos pistonPos;
    private BlockPos redstonePos;
    private BlockPos supportPos;
    private final List<BlockPos> supportPositions = new ArrayList<BlockPos>();
    private Direction pushDir;
    private Player currentTarget;
    private long lastActionMs = 0L;
    private long extendedSinceMs = 0L;
    private long leverTurnedOnMs = 0L;

    public PistonKickModule() {
        INSTANCE = this;
    }

    public static PistonKickModule getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.resetState();
    }

    @Override
    public void onDisable() {
        this.resetState();
    }

    private void resetState() {
        this.targetPhasedPos = null;
        this.pistonPos = null;
        this.redstonePos = null;
        this.supportPos = null;
        this.supportPositions.clear();
        this.pushDir = null;
        this.currentTarget = null;
        this.extendedSinceMs = 0L;
        this.leverTurnedOnMs = 0L;
    }

    @SubscribeEvent
    public void onTick(TickEvent tickEvent) {
        int n;
        boolean bl;
        boolean bl2;
        List<Player> list;
        if (PistonKickModule.mc.player == null || PistonKickModule.mc.level == null) {
            return;
        }
        if (this.pauseOnEat.getValue() && EntityUtils.isEating()) {
            return;
        }
        long l = System.currentTimeMillis();
        if (l - this.lastActionMs < this.delay.getValue().longValue() * 50L) {
            return;
        }
        int n2 = this.findPiston();
        int n3 = this.findPower();
        if (n2 == -1 || n3 == -1) {
            this.resetState();
            return;
        }
        if (this.currentTarget != null) {
            if (!this.currentTarget.isAlive() || this.currentTarget.isSpectator() || PistonKickModule.mc.player.distanceToSqr((Entity)this.currentTarget) > (double)(this.targetRange.getValue().floatValue() * this.targetRange.getValue().floatValue())) {
                this.resetState();
            } else {
                list = this.getPhasedSolidBlocks(this.currentTarget);
                if (list.isEmpty()) {
                    this.resetState();
                } else if (this.targetPhasedPos == null || !list.contains(this.targetPhasedPos)) {
                    this.targetPhasedPos = (BlockPos)list.get(0);
                }
            }
        }
        if (this.currentTarget == null) {
            list = this.getEnemies();
            for (Player object : list) {
                BlockPos bl6;
                if (!this.inAirTarget.getValue() && !object.onGround() || (bl6 = this.getPhasedSolidBlocks(object)).isEmpty()) continue;
                this.currentTarget = object;
                this.targetPhasedPos = bl6.get(0);
                break;
            }
        }
        if (this.currentTarget == null || this.targetPhasedPos == null) {
            this.resetState();
            return;
        }
        if (this.breakCrystal.getValue()) {
            this.breakNearbyCrystals(this.currentTarget);
        }
        if (this.pistonPos != null && this.pushDir != null) {
            boolean bl3 = this.isPistonPlacedAndFacing(this.pistonPos, this.pushDir);
            boolean bl4 = this.isPistonExtended(this.pistonPos);
            boolean bl5 = this.isPistonPowered(this.pistonPos);
            boolean bl13 = this.power.getValue().equalsIgnoreCase("Lever");
            if (bl4) {
                long bl22;
                if (this.extendedSinceMs == 0L) {
                    this.extendedSinceMs = l;
                }
                if (l - this.extendedSinceMs < (bl22 = Math.max(50L, this.pushDelay.getValue().longValue())) || this.leverTurnedOnMs > 0L && l - this.leverTurnedOnMs < 50L) {
                    this.lastActionMs = l;
                    return;
                }
                if (bl13 && this.redstonePos != null && this.isLever(this.redstonePos) && this.isLeverPowered(this.redstonePos)) {
                    this.clickLever(this.redstonePos);
                    this.leverTurnedOnMs = 0L;
                    this.lastActionMs = l;
                    return;
                }
                if (bl13 && this.redstonePos != null && !this.isLeverPowered(this.redstonePos) && bl4) {
                    this.lastActionMs = l;
                    return;
                }
                List<BlockPos> bl7 = this.getPhasedSolidBlocks(this.currentTarget);
                if (bl7.isEmpty()) {
                    this.resetState();
                    return;
                }
                this.pistonPos = null;
                this.redstonePos = null;
                this.supportPos = null;
                this.pushDir = null;
                this.extendedSinceMs = 0L;
                this.leverTurnedOnMs = 0L;
                this.lastActionMs = l;
            } else {
                this.extendedSinceMs = 0L;
            }
            if (bl3 && bl5 && !bl4) {
                this.lastActionMs = l;
                return;
            }
            bl2 = this.airPlace.getValue();
            if (!bl3 && !PistonHelper.canPlace(this.pistonPos, null, bl2, true)) {
                bl = !bl13 && this.redstonePos != null && this.redstonePos.equals((Object)this.pistonPos.below()) && (PistonHelper.canPlace(this.redstonePos, null, bl2, true) || this.isPowerSource(this.redstonePos)) || !this.supportPositions.isEmpty() && this.supportPositions.stream().anyMatch(blockPos -> PistonHelper.canPlace(blockPos, null, bl22, true) || this.isSolidBlock((BlockPos)blockPos)) || this.supportPos != null && (PistonHelper.canPlace(this.supportPos, null, bl2, true) || this.isSolidBlock(this.supportPos));
                boolean bl6 = bl;
                if (!bl) {
                    this.resetState();
                }
            }
        }
        if (!(this.pistonPos != null && this.pushDir != null || this.searchPlacement(this.currentTarget))) {
            return;
        }
        if (this.pistonPos == null || this.pushDir == null) {
            return;
        }
        boolean bl8 = this.airPlace.getValue();
        boolean bl9 = this.power.getValue().equalsIgnoreCase("Lever");
        for (BlockPos bl6 : this.supportPositions) {
            if (this.isSolidBlock(bl6) || !PistonHelper.canPlace(bl6, null, bl8, true) || (bl2 = this.findSupportBlock())) continue;
            this.placeBlock(bl2 ? 1 : 0, bl6, null);
            this.lastActionMs = l;
            if (this.oneTwelve.getValue() || this.merge.getValue()) continue;
            return;
        }
        if (this.supportPos != null && !this.isSolidBlock(this.supportPos) && !this.supportPositions.contains(this.supportPos) && PistonHelper.canPlace(this.supportPos, null, bl8, true) && (n = this.findSupportBlock()) != -1) {
            this.placeBlock(n, this.supportPos, null);
            this.lastActionMs = l;
            if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                return;
            }
        }
        boolean bl7 = !bl9 && this.redstonePos != null && this.redstonePos.equals((Object)this.pistonPos.below());
        boolean bl10 = bl7;
        if (bl7 && !this.isPowerSource(this.redstonePos) && PistonHelper.canPlace(this.redstonePos, null, bl8, true)) {
            this.placeBlock(n3, this.redstonePos, null);
            this.lastActionMs = l;
            if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                return;
            }
        }
        boolean bl11 = !this.isPistonPlacedAndFacing(this.pistonPos, this.pushDir);
        boolean bl12 = bl11;
        if (bl11 && PistonHelper.canPlace(this.pistonPos, null, bl8, true)) {
            this.placeBlock(n2, this.pistonPos, this.pushDir);
            this.lastActionMs = l;
            if (!this.oneTwelve.getValue() && !this.merge.getValue()) {
                return;
            }
        }
        if (this.redstonePos != null && !this.isPistonPowered(this.pistonPos) && !this.isPowerSource(this.redstonePos)) {
            bl2 = !bl9 || this.isPistonPlacedAndFacing(this.pistonPos, this.pushDir) || bl8;
            bl = bl2;
            if (bl2 && PistonHelper.canPlace(this.redstonePos, null, bl8, true)) {
                this.placeBlock(n3, this.redstonePos, null);
                this.lastActionMs = l;
                if (bl9) {
                    this.clickLever(this.redstonePos);
                    this.leverTurnedOnMs = l;
                }
            }
        } else if (bl9 && this.redstonePos != null && this.isLever(this.redstonePos) && !this.isLeverPowered(this.redstonePos) && !this.isPistonExtended(this.pistonPos) && this.extendedSinceMs == 0L) {
            this.clickLever(this.redstonePos);
            this.leverTurnedOnMs = l;
            this.lastActionMs = l;
        }
    }

    private boolean searchPlacement(Player player) {
        List<BlockPos> list = this.getPhasedSolidBlocks(player);
        if (list.isEmpty()) {
            return false;
        }
        if (list.size() >= 2) {
            Direction direction = PistonKickModule.mc.player.getDirection();
            Direction.Axis axis = direction.getAxis();
            list.sort((blockPos, blockPos2) -> {
                boolean bl = axis == Direction.Axis.Z && blockPos.getZ() != blockPos2.getZ() || axis == Direction.Axis.X && blockPos.getX() != blockPos2.getX();
                return bl ? -1 : 1;
            });
        }
        for (BlockPos blockPos3 : list) {
            if (!this.searchPlacementForBlock(player, blockPos3)) continue;
            this.targetPhasedPos = blockPos3;
            return true;
        }
        return false;
    }

    private boolean searchPlacementForBlock(Player player, BlockPos blockPos) {
        ArrayList<Direction> arrayList = new ArrayList<Direction>();
        Direction direction = PistonKickModule.mc.player.getDirection();
        arrayList.add(direction);
        for (Direction direction2 : Direction.Plane.HORIZONTAL) {
            if (direction2 == direction) continue;
            arrayList.add(direction2);
        }
        Iterator iterator = blockPos.above();
        boolean bl = this.airPlace.getValue();
        boolean bl2 = this.power.getValue().equalsIgnoreCase("Lever");
        for (Direction direction3 : arrayList) {
            BlockPos blockPos2;
            BlockPos blockPos3;
            Object object;
            Object object2;
            Object object3;
            BlockPos blockPos4;
            BlockPos blockPos5;
            Object object4;
            BlockPos blockPos6;
            Object object5;
            BlockPos blockPos8;
            Object object6;
            if (!this.isDestinationOpen(blockPos, direction3)) continue;
            BlockPos blockPos9 = iterator.relative(direction3.getOpposite());
            if (!PistonKickModule.mc.level.getBlockState((BlockPos)iterator).isAir() && !PistonKickModule.mc.level.getBlockState((BlockPos)iterator).canBeReplaced() || !this.inRange(blockPos9)) continue;
            boolean bl3 = this.isPistonPlacedAndFacing(blockPos9, direction3);
            boolean bl4 = PistonKickModule.mc.level.getBlockState(blockPos9).isAir() || PistonKickModule.mc.level.getBlockState(blockPos9).canBeReplaced();
            boolean bl5 = bl4;
            if (!bl3 && !bl4) continue;
            boolean bl6 = bl3 || PistonHelper.canPlace(blockPos9, null, bl, true);
            boolean bl7 = bl6;
            if (bl6) {
                if (this.isPistonPowered(blockPos9)) {
                    this.supportPos = null;
                    this.pistonPos = blockPos9;
                    this.redstonePos = null;
                    this.pushDir = direction3;
                    return true;
                }
                if (bl2) {
                    BlockPos blockPos7;
                    object6 = blockPos9.below();
                    boolean bl8 = !bl && !this.isSolidBlock((BlockPos)object6);
                    blockPos8 = new ArrayList();
                    object5 = blockPos9.relative(direction3.getOpposite());
                    BlockPos blockPos10 = object5.below();
                    blockPos6 = new ArrayList();
                    if (bl8) {
                        blockPos6.add(object6);
                    }
                    if (!bl && !this.isSolidBlock(blockPos10)) {
                        blockPos6.add((BlockPos)blockPos10);
                    }
                    blockPos8.add(new LeverCandidate((BlockPos)object5, (List<BlockPos>)blockPos6));
                    object4 = blockPos9.relative(direction3.getCounterClockWise());
                    blockPos5 = object4.below();
                    blockPos4 = new ArrayList();
                    if (bl8) {
                        blockPos4.add(object6);
                    }
                    if (!bl && !this.isSolidBlock(blockPos5)) {
                        blockPos4.add((BlockPos)blockPos5);
                    }
                    blockPos8.add(new LeverCandidate((BlockPos)object4, (List<BlockPos>)blockPos4));
                    if (this.isSolidBlock((BlockPos)object4)) {
                        object3 = object4.above();
                        object2 = new ArrayList();
                        if (bl8) {
                            ((ArrayList)object2).add(object6);
                        }
                        blockPos8.add(new LeverCandidate((BlockPos)object3, (List<BlockPos>)object2));
                    }
                    object3 = blockPos9.relative(direction3.getClockWise());
                    object2 = object3.below();
                    object = new ArrayList<BlockPos>();
                    if (bl8) {
                        ((ArrayList)object).add(object6);
                    }
                    if (!bl && !this.isSolidBlock((BlockPos)object2)) {
                        ((ArrayList)object).add((BlockPos)object2);
                    }
                    blockPos8.add(new LeverCandidate((BlockPos)object3, (List<BlockPos>)object));
                    if (this.isSolidBlock((BlockPos)object3)) {
                        blockPos7 = object3.above();
                        blockPos3 = new ArrayList();
                        if (bl8) {
                            blockPos3.add(object6);
                        }
                        blockPos8.add(new LeverCandidate(blockPos7, (List<BlockPos>)blockPos3));
                    }
                    if (this.isSolidBlock((BlockPos)object5)) {
                        blockPos7 = blockPos9.relative(direction3.getOpposite(), 2);
                        blockPos3 = new ArrayList();
                        if (bl8) {
                            blockPos3.add((BlockPos)object6);
                        }
                        blockPos8.add(new LeverCandidate(blockPos7, (List<BlockPos>)blockPos3));
                        BlockPos blockPos11 = object5.above();
                        Object object7 = new ArrayList<Object>();
                        if (bl8) {
                            ((ArrayList)object7).add(object6);
                        }
                        blockPos8.add(new LeverCandidate(blockPos11, (List<BlockPos>)object7));
                    }
                    blockPos7 = blockPos9.relative(direction3.getOpposite()).below();
                    blockPos3 = new ArrayList();
                    if (bl8) {
                        blockPos3.add((BlockPos)object6);
                    }
                    blockPos8.add(new LeverCandidate(blockPos7, (List<BlockPos>)blockPos3));
                    for (Object object7 : blockPos8) {
                        BlockPos blockPos12 = ((LeverCandidate)object7).leverPos;
                        if (blockPos12.equals((Object)blockPos9.relative(direction3)) || blockPos12.equals((Object)iterator) || blockPos12.equals((Object)iterator.below()) || blockPos12.equals((Object)blockPos.relative(direction3)) || blockPos12.equals((Object)iterator.relative(direction3)) || !this.inRange(blockPos12)) continue;
                        boolean bl9 = this.isLever(blockPos12) || PistonKickModule.mc.level.getBlockState(blockPos12).isAir() || PistonKickModule.mc.level.getBlockState(blockPos12).canBeReplaced();
                        boolean bl10 = bl9;
                        if (!bl9) continue;
                        boolean bl11 = true;
                        for (BlockPos blockPos13 : ((LeverCandidate)object7).neededSupports) {
                            if (blockPos13.equals((Object)iterator) || blockPos13.equals((Object)iterator.below()) || blockPos13.equals((Object)blockPos.relative(direction3)) || blockPos13.equals((Object)iterator.relative(direction3))) {
                                bl11 = false;
                                break;
                            }
                            if (!this.inRange(blockPos13)) {
                                bl11 = false;
                                break;
                            }
                            if (this.isSolidBlock(blockPos13) || PistonHelper.canPlace(blockPos13, null, bl, true)) continue;
                            bl11 = false;
                            break;
                        }
                        if (!bl11) continue;
                        this.supportPositions.clear();
                        this.supportPositions.addAll(((LeverCandidate)object7).neededSupports);
                        this.supportPos = ((LeverCandidate)object7).neededSupports.isEmpty() ? null : ((LeverCandidate)object7).neededSupports.get(0);
                        this.pistonPos = blockPos9;
                        this.redstonePos = blockPos12;
                        this.pushDir = direction3;
                        return true;
                    }
                } else {
                    object6 = this.findBestPowerPos(blockPos9, (BlockPos)iterator, blockPos.relative(direction3), direction3);
                    if (object6 != null) {
                        this.supportPos = null;
                        this.pistonPos = blockPos9;
                        this.redstonePos = object6;
                        this.pushDir = direction3;
                        return true;
                    }
                    for (Direction direction2 : new Direction[]{Direction.UP, direction3.getOpposite(), direction3.getClockWise(), direction3.getCounterClockWise(), Direction.DOWN}) {
                        blockPos6 = blockPos9.relative(direction2);
                        if (blockPos6.equals((Object)blockPos9.relative(direction3)) || blockPos6.equals((Object)iterator) || blockPos6.equals((Object)iterator.below()) || blockPos6.equals((Object)blockPos.relative(direction3)) || blockPos6.equals((Object)iterator.relative(direction3)) || !this.inRange(blockPos6) || !PistonKickModule.mc.level.getBlockState(blockPos6).isAir() && !PistonKickModule.mc.level.getBlockState(blockPos6).canBeReplaced() || !bl && !PistonHelper.canPlace(blockPos6, null, false, true)) continue;
                        this.supportPos = null;
                        this.pistonPos = blockPos9;
                        this.redstonePos = blockPos6;
                        this.pushDir = direction3;
                        return true;
                    }
                }
            }
            if (bl || !bl4 || !this.inRange(blockPos2 = blockPos9.below())) continue;
            if (bl2) {
                if (!PistonHelper.canPlace(blockPos2, null, false, true) && !this.isSolidBlock(blockPos2)) continue;
                object6 = new ArrayList();
                BlockPos blockPos14 = blockPos9.relative(direction3.getOpposite());
                blockPos8 = blockPos14.below();
                object5 = new ArrayList();
                if (!this.isSolidBlock(blockPos2)) {
                    ((ArrayList)object5).add(blockPos2);
                }
                if (!this.isSolidBlock(blockPos8)) {
                    ((ArrayList)object5).add(blockPos8);
                }
                ((ArrayList)object6).add(new LeverCandidate(blockPos14, (List<BlockPos>)object5));
                BlockPos blockPos15 = blockPos9.relative(direction3.getCounterClockWise());
                blockPos6 = blockPos15.below();
                object4 = new ArrayList();
                if (!this.isSolidBlock(blockPos2)) {
                    ((ArrayList)object4).add(blockPos2);
                }
                if (!this.isSolidBlock(blockPos6)) {
                    ((ArrayList)object4).add(blockPos6);
                }
                ((ArrayList)object6).add(new LeverCandidate(blockPos15, (List<BlockPos>)object4));
                blockPos5 = blockPos9.relative(direction3.getClockWise());
                blockPos4 = blockPos5.below();
                object3 = new ArrayList();
                if (!this.isSolidBlock(blockPos2)) {
                    ((ArrayList)object3).add(blockPos2);
                }
                if (!this.isSolidBlock(blockPos4)) {
                    ((ArrayList)object3).add(blockPos4);
                }
                ((ArrayList)object6).add(new LeverCandidate(blockPos5, (List<BlockPos>)object3));
                object2 = ((ArrayList)object6).iterator();
                while (object2.hasNext()) {
                    object = (LeverCandidate)object2.next();
                    blockPos3 = ((LeverCandidate)object).leverPos;
                    if (blockPos3.equals((Object)blockPos9.relative(direction3)) || blockPos3.equals((Object)iterator) || blockPos3.equals((Object)iterator.below()) || blockPos3.equals((Object)blockPos.relative(direction3)) || blockPos3.equals((Object)iterator.relative(direction3)) || !this.inRange(blockPos3)) continue;
                    boolean bl12 = this.isLever(blockPos3) || PistonKickModule.mc.level.getBlockState(blockPos3).isAir() || PistonKickModule.mc.level.getBlockState(blockPos3).canBeReplaced();
                    boolean bl13 = bl12;
                    if (!bl12) continue;
                    boolean bl14 = true;
                    for (BlockPos blockPos12 : ((LeverCandidate)object).neededSupports) {
                        if (blockPos12.equals((Object)iterator) || blockPos12.equals((Object)iterator.below()) || blockPos12.equals((Object)blockPos.relative(direction3)) || blockPos12.equals((Object)iterator.relative(direction3))) {
                            bl14 = false;
                            break;
                        }
                        if (this.inRange(blockPos12) && (this.isSolidBlock(blockPos12) || PistonHelper.canPlace(blockPos12, null, false, true))) continue;
                        bl14 = false;
                        break;
                    }
                    if (!bl14) continue;
                    this.supportPositions.clear();
                    this.supportPositions.addAll(((LeverCandidate)object).neededSupports);
                    this.supportPos = ((LeverCandidate)object).neededSupports.isEmpty() ? null : ((LeverCandidate)object).neededSupports.get(0);
                    this.pistonPos = blockPos9;
                    this.redstonePos = blockPos3;
                    this.pushDir = direction3;
                    return true;
                }
                continue;
            }
            if (!PistonHelper.canPlace(blockPos2, null, false, true) && !this.isPowerSource(blockPos2)) continue;
            this.supportPositions.clear();
            this.supportPos = null;
            this.pistonPos = blockPos9;
            this.redstonePos = blockPos2;
            this.pushDir = direction3;
            return true;
        }
        return false;
    }

    private BlockPos findBestPowerPos(BlockPos blockPos, BlockPos blockPos2, BlockPos blockPos3, Direction direction) {
        BlockPos blockPos4 = null;
        double d = Double.MAX_VALUE;
        boolean bl = this.airPlace.getValue();
        Direction[] directionArray = new Direction[]{Direction.DOWN, direction.getOpposite(), direction.getClockWise(), direction.getCounterClockWise(), Direction.UP};
        for (Direction direction2 : directionArray) {
            double d2;
            BlockPos blockPos5 = blockPos.relative(direction2);
            if (blockPos5.equals((Object)blockPos2) || blockPos5.equals((Object)blockPos2.below()) || blockPos5.equals((Object)blockPos3) || blockPos5.equals((Object)blockPos3.above()) || blockPos5.equals((Object)blockPos.relative(direction))) continue;
            if (this.isPowerSource(blockPos5)) {
                return blockPos5;
            }
            if (!PistonHelper.canPlace(blockPos5, null, bl, true) || !this.inRange(blockPos5) || !((d2 = PistonKickModule.mc.player.distanceToSqr(Vec3.atCenterOf((Vec3i)blockPos5))) < d)) continue;
            d = d2;
            blockPos4 = blockPos5;
        }
        return blockPos4;
    }

    private void placeBlock(int n, BlockPos blockPos, Direction direction2) {
        if (n == -1 || PistonKickModule.mc.player == null) {
            return;
        }
        Direction direction3 = this.strictDirection.getValue() ? WorldUtils.getDirection(blockPos, true) : PistonHelper.getPlaceSide(blockPos, direction -> true);
        Direction direction4 = direction3;
        if (direction3 == null) {
            if (this.airPlace.getValue()) {
                if (this.power.getValue().equalsIgnoreCase("Lever") && this.pistonPos != null && this.pushDir != null && blockPos.equals((Object)this.pistonPos.relative(this.pushDir.getOpposite()))) {
                    direction3 = this.pushDir;
                } else {
                    direction3 = PistonHelper.getClickSide(blockPos);
                    if (direction3 == null) {
                        direction3 = Direction.UP;
                    }
                }
            } else {
                return;
            }
        }
        int n2 = PistonKickModule.mc.player.getInventory().getSelectedSlot();
        this.doSwap(n, n2);
        if (this.shouldRotate()) {
            this.doRotate(blockPos, direction3);
            if (direction2 != null) {
                this.snapPistonFacing(direction2);
            }
        }
        PistonHelper.placeBlock(blockPos, direction3, false);
        this.restoreSlot(n, n2);
        if (this.render.getValue()) {
            Night.RENDER_MANAGER.getRenderPositions().removeIf(renderPosition -> renderPosition.getPos().equals((Object)blockPos));
            Night.RENDER_MANAGER.getRenderPositions().add(new RenderPosition(blockPos));
        }
    }

    private void snapPistonFacing(Direction direction) {
        float f = switch (direction) {
            case Direction.SOUTH -> 180.0f;
            case Direction.NORTH -> 0.0f;
            case Direction.EAST -> 90.0f;
            case Direction.WEST -> -90.0f;
            default -> 0.0f;
        };
        Night.ROTATION_MANAGER.silentRotate(f, 0.0f);
    }

    private boolean isPistonPlacedAndFacing(BlockPos blockPos, Direction direction) {
        if (PistonKickModule.mc.level == null) {
            return false;
        }
        BlockState blockState = PistonKickModule.mc.level.getBlockState(blockPos);
        if (blockState.getBlock() instanceof PistonBaseBlock) {
            return blockState.getValue((Property)PistonBaseBlock.FACING) == direction;
        }
        return false;
    }

    private boolean isPistonExtended(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null) {
            return false;
        }
        BlockState blockState = PistonKickModule.mc.level.getBlockState(blockPos);
        if (blockState.getBlock() instanceof PistonBaseBlock) {
            return (Boolean)blockState.getValue((Property)PistonBaseBlock.EXTENDED);
        }
        return false;
    }

    private boolean isPistonPowered(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null) {
            return false;
        }
        if (this.power.getValue().equalsIgnoreCase("Lever")) {
            for (Direction direction : Direction.values()) {
                BlockPos blockPos2 = blockPos.relative(direction);
                if (!this.isLever(blockPos2) || !this.isLeverPowered(blockPos2)) continue;
                return true;
            }
            return PistonKickModule.mc.level.hasNeighborSignal(blockPos);
        }
        for (Direction direction : Direction.values()) {
            if (!this.isRedstone(blockPos.relative(direction))) continue;
            return true;
        }
        return false;
    }

    private boolean isPowerSource(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null || blockPos == null) {
            return false;
        }
        Block block = PistonKickModule.mc.level.getBlockState(blockPos).getBlock();
        if (this.power.getValue().equalsIgnoreCase("Lever")) {
            return block == Blocks.LEVER;
        }
        return block == Blocks.REDSTONE_BLOCK || block == Blocks.REDSTONE_TORCH;
    }

    private boolean isRedstone(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null) {
            return false;
        }
        Block block = PistonKickModule.mc.level.getBlockState(blockPos).getBlock();
        return block == Blocks.REDSTONE_BLOCK || block == Blocks.REDSTONE_TORCH;
    }

    private boolean isLever(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null || blockPos == null) {
            return false;
        }
        return PistonKickModule.mc.level.getBlockState(blockPos).getBlock() == Blocks.LEVER;
    }

    private boolean isLeverPowered(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null || blockPos == null) {
            return false;
        }
        BlockState blockState = PistonKickModule.mc.level.getBlockState(blockPos);
        if (blockState.getBlock() == Blocks.LEVER) {
            return (Boolean)blockState.getValue((Property)LeverBlock.POWERED);
        }
        return false;
    }

    private void clickLever(BlockPos blockPos) {
        if (PistonKickModule.mc.player == null || PistonKickModule.mc.level == null) {
            return;
        }
        Direction direction = PistonHelper.getClickSide(blockPos);
        if (direction == null) {
            direction = Direction.UP;
        }
        PistonHelper.clickBlock(blockPos, direction, this.shouldRotate());
    }

    private boolean isDestinationOpen(BlockPos blockPos, Direction direction) {
        if (PistonKickModule.mc.level == null) {
            return false;
        }
        BlockPos blockPos2 = blockPos.relative(direction);
        BlockPos blockPos3 = blockPos2.above();
        BlockState blockState = PistonKickModule.mc.level.getBlockState(blockPos2);
        BlockState blockState2 = PistonKickModule.mc.level.getBlockState(blockPos3);
        if (!blockState.isAir() && (!blockState.canBeReplaced() || blockState.blocksMotion() || this.isImmovable(blockState))) {
            return false;
        }
        return blockState2.isAir() || blockState2.canBeReplaced() && !blockState2.blocksMotion() && !this.isImmovable(blockState2);
    }

    private boolean isImmovable(BlockState blockState) {
        Block block = blockState.getBlock();
        return block == Blocks.OBSIDIAN || block == Blocks.BEDROCK || block == Blocks.CRYING_OBSIDIAN || block == Blocks.RESPAWN_ANCHOR || block == Blocks.ENDER_CHEST || blockState.isSolid();
    }

    public List<BlockPos> getPhasedSolidBlocks(Player player) {
        BlockState blockState;
        ArrayList<BlockPos> arrayList = new ArrayList<BlockPos>();
        if (player == null || PistonKickModule.mc.level == null) {
            return arrayList;
        }
        List<BlockPos> list = EntityUtils.getPhasedBlocks((Entity)player);
        for (BlockPos blockPos2 : list) {
            blockState = PistonKickModule.mc.level.getBlockState(blockPos2);
            if (!this.isHardPhasedBlock(blockState)) continue;
            arrayList.add(blockPos2);
        }
        if (arrayList.isEmpty()) {
            BlockPos blockPos = BlockPos.containing((double)player.getX(), (double)(player.getY() + 0.1), (double)player.getZ());
            if (this.isHardPhasedBlock(PistonKickModule.mc.level.getBlockState(blockPos))) {
                arrayList.add(blockPos);
            } else {
                BlockPos blockPos2;
                blockPos2 = player.blockPosition();
                if (this.isHardPhasedBlock(PistonKickModule.mc.level.getBlockState(blockPos2))) {
                    arrayList.add(blockPos2);
                } else {
                    blockState = blockPos.above();
                    if (this.isHardPhasedBlock(PistonKickModule.mc.level.getBlockState((BlockPos)blockState))) {
                        arrayList.add((BlockPos)blockState);
                    }
                }
            }
        }
        return arrayList;
    }

    public BlockPos getPhasedSolidBlock(Player player) {
        List<BlockPos> list = this.getPhasedSolidBlocks(player);
        return list.isEmpty() ? null : list.get(0);
    }

    private boolean isDecoyOrPassableBlock(BlockState blockState) {
        if (blockState == null || blockState.isAir() || blockState.canBeReplaced()) {
            return true;
        }
        Block block = blockState.getBlock();
        return block instanceof WebBlock || block instanceof ButtonBlock || block instanceof MushroomBlock || block instanceof LadderBlock || block instanceof ScaffoldingBlock || block instanceof FlowerBlock || block instanceof FlowerPotBlock || block instanceof TallFlowerBlock || block instanceof VineBlock || block instanceof TorchBlock || block instanceof LeverBlock || block instanceof PressurePlateBlock || block instanceof SignBlock || block instanceof BannerBlock || block instanceof CarpetBlock || block instanceof TripWireBlock || block instanceof TripWireHookBlock || block instanceof BaseRailBlock || block == Blocks.COBWEB || block == Blocks.LADDER || block == Blocks.SCAFFOLDING || block == Blocks.VINE || block == Blocks.BROWN_MUSHROOM || block == Blocks.RED_MUSHROOM || block == Blocks.TORCH || block == Blocks.SOUL_TORCH || block == Blocks.REDSTONE_TORCH;
    }

    private boolean isHardPhasedBlock(BlockState blockState) {
        if (this.isDecoyOrPassableBlock(blockState)) {
            return false;
        }
        Block block = blockState.getBlock();
        if (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK || block == Blocks.ENDER_CHEST || block == Blocks.RESPAWN_ANCHOR || block == Blocks.CRYING_OBSIDIAN || block == Blocks.ANVIL || block == Blocks.CHIPPED_ANVIL || block == Blocks.DAMAGED_ANVIL || block == Blocks.REINFORCED_DEEPSLATE || block == Blocks.NETHERITE_BLOCK || block == Blocks.ANCIENT_DEBRIS) {
            return true;
        }
        return blockState.isSolid() && blockState.blocksMotion();
    }

    private boolean inRange(BlockPos blockPos) {
        double d = this.placeRange.getValue().floatValue();
        return PistonKickModule.mc.player.distanceToSqr(Vec3.atCenterOf((Vec3i)blockPos)) <= d * d;
    }

    private void breakNearbyCrystals(Player player) {
        double d = this.breakRange.getValue().floatValue();
        AABB aABB = player.getBoundingBox().inflate(d);
        PistonKickModule.mc.level.getEntitiesOfClass(EndCrystal.class, aABB, endCrystal -> endCrystal.isAlive() && PistonKickModule.mc.player.distanceToSqr((Entity)endCrystal) <= d * d).stream().min(Comparator.comparingDouble(endCrystal -> PistonKickModule.mc.player.distanceToSqr((Entity)endCrystal))).ifPresent(endCrystal -> {
            float f = DamageUtils.getCrystalDamage((Entity)PistonKickModule.mc.player, null, endCrystal, false);
            if (f > this.maxLocalDamage.getValue().floatValue()) {
                return;
            }
            if (this.safety.getValue() && f >= PistonKickModule.mc.player.getHealth() + PistonKickModule.mc.player.getAbsorptionAmount()) {
                return;
            }
            mc.getConnection().send((Packet)new ServerboundAttackPacket(endCrystal.getId()));
            mc.getConnection().send((Packet)new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
        });
    }

    private boolean shouldRotate() {
        return !this.rotate.getValue().equalsIgnoreCase("None");
    }

    private void doRotate(BlockPos blockPos, Direction direction) {
        Vec3 vec3 = Vec3.atCenterOf((Vec3i)blockPos).add((double)direction.getStepX() * 0.5, (double)direction.getStepY() * 0.5, (double)direction.getStepZ() * 0.5);
        float[] fArray = RotationUtils.getRotations(vec3);
        Night.ROTATION_MANAGER.silentRotate(fArray[0], fArray[1]);
    }

    private void doSwap(int n, int n2) {
        InventoryUtils.switchSlot(this.swapAction.getValue(), n, n2);
    }

    private void restoreSlot(int n, int n2) {
        InventoryUtils.switchBack(this.swapAction.getValue(), n, n2);
    }

    private int findPower() {
        if (this.power.getValue().equalsIgnoreCase("Lever")) {
            return this.findBlock(Blocks.LEVER);
        }
        int n = this.findBlock(Blocks.REDSTONE_BLOCK);
        if (n != -1) {
            return n;
        }
        return this.findBlock(Blocks.REDSTONE_TORCH);
    }

    private int findSupportBlock() {
        int n = this.findBlock(Blocks.OBSIDIAN);
        if (n != -1) {
            return n;
        }
        n = this.findBlock(Blocks.CRYING_OBSIDIAN);
        if (n != -1) {
            return n;
        }
        n = this.findBlock(Blocks.ENDER_CHEST);
        if (n != -1) {
            return n;
        }
        n = this.findBlock(Blocks.NETHERITE_BLOCK);
        if (n != -1) {
            return n;
        }
        n = this.findBlock(Blocks.COBBLESTONE);
        if (n != -1) {
            return n;
        }
        return this.findPower();
    }

    private boolean isSolidBlock(BlockPos blockPos) {
        if (PistonKickModule.mc.level == null || blockPos == null) {
            return false;
        }
        BlockState blockState = PistonKickModule.mc.level.getBlockState(blockPos);
        return !blockState.isAir() && !blockState.canBeReplaced() && blockState.isSolid();
    }

    private int findPiston() {
        int n = this.findBlock(Blocks.PISTON);
        if (n != -1) {
            return n;
        }
        return this.findBlock(Blocks.STICKY_PISTON);
    }

    private int findBlock(Block block) {
        if (this.swapAction.getValue().equalsIgnoreCase("None")) {
            BlockItem blockItem;
            Item item;
            ItemStack itemStack = PistonKickModule.mc.player.getMainHandItem();
            if (!itemStack.isEmpty() && (item = itemStack.getItem()) instanceof BlockItem && (blockItem = (BlockItem)item).getBlock() == block) {
                return PistonKickModule.mc.player.getInventory().getSelectedSlot();
            }
            return -1;
        }
        int n = this.swapAction.getValue().equalsIgnoreCase("AltSwap") || this.swapAction.getValue().equalsIgnoreCase("AltPickup") ? InventoryUtils.INVENTORY_END : InventoryUtils.HOTBAR_END;
        for (int i = 0; i <= n; ++i) {
            BlockItem blockItem;
            Item item;
            ItemStack itemStack = PistonKickModule.mc.player.getInventory().getItem(i);
            if (itemStack.isEmpty() || !((item = itemStack.getItem()) instanceof BlockItem) || (blockItem = (BlockItem)item).getBlock() != block) continue;
            return i;
        }
        return -1;
    }

    private List<Player> getEnemies() {
        double d = this.targetRange.getValue().floatValue();
        return PistonKickModule.mc.level.players().stream().filter(abstractClientPlayer -> abstractClientPlayer != PistonKickModule.mc.player).filter(abstractClientPlayer -> !EntityUtils.isGhost((Entity)abstractClientPlayer)).filter(abstractClientPlayer -> !abstractClientPlayer.isSpectator() && abstractClientPlayer.isAlive()).filter(abstractClientPlayer -> !Night.FRIEND_MANAGER.contains(abstractClientPlayer.getName().getString())).filter(abstractClientPlayer -> PistonKickModule.mc.player.distanceToSqr((Entity)abstractClientPlayer) <= d * d).sorted(Comparator.comparingDouble(abstractClientPlayer -> PistonKickModule.mc.player.distanceToSqr((Entity)abstractClientPlayer))).collect(Collectors.toList());
    }

    private record LeverCandidate(BlockPos leverPos, List<BlockPos> neededSupports) {
    }
}

