/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.NonNullList
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientboundContainerSetContentPacket
 *  net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket
 *  net.minecraft.network.protocol.game.ClientboundOpenScreenPacket
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.block.Blocks
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.HitResult
 */
package lightning.utils.minecraft;

import lightning.Night;
import lightning.events.SubscribeEvent;
import lightning.events.impl.PacketReceiveEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundContainerSetContentPacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public final class EChestMemory {
    private static final EChestMemory INSTANCE = new EChestMemory();
    private static boolean registered = false;
    private static NonNullList<ItemStack> items = null;
    private int trackedContainerId = -1;

    private EChestMemory() {
    }

    public static void init() {
        if (registered) {
            return;
        }
        registered = true;
        Night.EVENT_HANDLER.subscribe(INSTANCE);
    }

    public static boolean hasItems() {
        return items != null;
    }

    public static NonNullList<ItemStack> getItems() {
        return items;
    }

    @SubscribeEvent
    public void onPacket(PacketReceiveEvent packetReceiveEvent) {
        ClientboundContainerSetContentPacket clientboundContainerSetContentPacket = packetReceiveEvent.getPacket();
        if (clientboundContainerSetContentPacket instanceof ClientboundOpenScreenPacket) {
            ClientboundOpenScreenPacket clientboundOpenScreenPacket = (ClientboundOpenScreenPacket)clientboundContainerSetContentPacket;
            if (this.isLookingAtEnderChest()) {
                this.trackedContainerId = clientboundOpenScreenPacket.getContainerId();
                items = NonNullList.withSize((int)27, (Object)ItemStack.EMPTY);
            } else {
                this.trackedContainerId = -1;
            }
        } else if (this.trackedContainerId != -1) {
            ClientboundContainerSetSlotPacket clientboundContainerSetSlotPacket = packetReceiveEvent.getPacket();
            if (!(clientboundContainerSetSlotPacket instanceof ClientboundContainerSetContentPacket)) {
                Packet<?> packet = packetReceiveEvent.getPacket();
                if (packet instanceof ClientboundContainerSetSlotPacket) {
                    clientboundContainerSetSlotPacket = (ClientboundContainerSetSlotPacket)packet;
                    if (clientboundContainerSetSlotPacket.getContainerId() != this.trackedContainerId) {
                        return;
                    }
                    int n = clientboundContainerSetSlotPacket.getSlot();
                    if (items != null && n >= 0 && n < 27) {
                        items.set(n, (Object)clientboundContainerSetSlotPacket.getItem().copy());
                    }
                }
            } else {
                clientboundContainerSetContentPacket = (ClientboundContainerSetContentPacket)clientboundContainerSetSlotPacket;
                if (clientboundContainerSetContentPacket.containerId() == this.trackedContainerId) {
                    clientboundContainerSetSlotPacket = NonNullList.withSize((int)27, (Object)ItemStack.EMPTY);
                    for (int i = 0; i < 27 && i < clientboundContainerSetContentPacket.items().size(); ++i) {
                        clientboundContainerSetSlotPacket.set(i, (Object)((ItemStack)clientboundContainerSetContentPacket.items().get(i)).copy());
                    }
                    items = clientboundContainerSetSlotPacket;
                }
            }
        }
    }

    private boolean isLookingAtEnderChest() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return false;
        }
        HitResult hitResult = minecraft.hitResult;
        if (!(hitResult instanceof BlockHitResult)) {
            return false;
        }
        BlockHitResult blockHitResult = (BlockHitResult)hitResult;
        BlockPos blockPos = blockHitResult.getBlockPos();
        return minecraft.level.getBlockState(blockPos).is((Object)Blocks.ENDER_CHEST);
    }
}

