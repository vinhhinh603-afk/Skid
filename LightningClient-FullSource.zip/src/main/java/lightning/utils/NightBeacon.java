/*
 * Decompiled with CFR 0.152.
 */
package lightning.utils;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;

public final class NightBeacon {
    public static final int MARK = 128;
    private static final boolean ENABLED = !"false".equalsIgnoreCase(System.getProperty("night.beacon", "true"));
    private static volatile boolean broken = false;
    private static Constructor<?> pktCtor;
    private static Constructor<?> infoCtor;
    private static Method pktGetter;
    private static int modelIdx;
    private static Method sendMethod;
    private static Field accessorField;
    private static Method getEntityData;
    private static Method dataGet;
    private static boolean inited;
    private static boolean readBroken;

    private NightBeacon() {
    }

    public static void pre(Object object, Object object2, Object object3, boolean bl, Object object4) {
        if (!ENABLED || broken || object2 == null) {
            return;
        }
        try {
            if (!"ServerboundClientInformationPacket".equals(object2.getClass().getSimpleName())) {
                return;
            }
            Object object5 = NightBeacon.rewrite(object2);
            if (object5 == null || object5 == object2) {
                return;
            }
            if (sendMethod == null) {
                block2: for (Class<?> clazz = object.getClass(); clazz != null && sendMethod == null; clazz = clazz.getSuperclass()) {
                    for (Method method : clazz.getDeclaredMethods()) {
                        Class<?>[] classArray = method.getParameterTypes();
                        if (!method.getName().equals("send") || classArray.length != 3 || classArray[2] != Boolean.TYPE) continue;
                        method.setAccessible(true);
                        sendMethod = method;
                        continue block2;
                    }
                }
            }
            if (sendMethod == null) {
                return;
            }
            sendMethod.invoke(object, object5, object3, bl);
            object4.getClass().getMethod("cancel", new Class[0]).invoke(object4, new Object[0]);
        }
        catch (Throwable throwable) {
            broken = true;
        }
    }

    private static Object rewrite(Object object) throws Exception {
        int n;
        Object[] objectArray;
        Object object2;
        Object object3;
        Class<?> clazz = object.getClass();
        if (pktCtor == null) {
            object3 = clazz.getRecordComponents();
            if (object3 == null || ((RecordComponent[])object3).length != 1) {
                throw new IllegalStateException();
            }
            pktGetter = ((RecordComponent)object3[0]).getAccessor();
            pktGetter.setAccessible(true);
            pktCtor = clazz.getDeclaredConstructor(((RecordComponent)object3[0]).getType());
            pktCtor.setAccessible(true);
            object2 = ((RecordComponent)object3[0]).getType();
            objectArray = ((Class)object2).getRecordComponents();
            Class[] classArray = new Class[objectArray.length];
            for (int i = 0; i < objectArray.length; ++i) {
                classArray[i] = ((RecordComponent)objectArray[i]).getType();
                if (!((RecordComponent)objectArray[i]).getName().toLowerCase().contains("modelcustom")) continue;
                modelIdx = i;
            }
            if (modelIdx < 0 || classArray[modelIdx] != Integer.TYPE) {
                throw new IllegalStateException();
            }
            infoCtor = ((Class)object2).getDeclaredConstructor(classArray);
            infoCtor.setAccessible(true);
        }
        object3 = pktGetter.invoke(object, new Object[0]);
        object2 = object3.getClass().getRecordComponents();
        objectArray = new Object[((RecordComponent[])object2).length];
        for (n = 0; n < ((RecordComponent[])object2).length; ++n) {
            Method method = object2[n].getAccessor();
            method.setAccessible(true);
            objectArray[n] = method.invoke(object3, new Object[0]);
        }
        n = (Integer)objectArray[modelIdx];
        if ((n & 0x80) != 0) {
            return object;
        }
        objectArray[NightBeacon.modelIdx] = n | 0x80;
        return pktCtor.newInstance(infoCtor.newInstance(objectArray));
    }

    public static boolean or(Object object, boolean bl) {
        return bl || NightBeacon.isMarked(object);
    }

    public static boolean isMarked(Object object) {
        if (!ENABLED || readBroken || object == null) {
            return false;
        }
        try {
            Byte by;
            AccessibleObject accessibleObject;
            int n;
            int n2;
            Object object2;
            Class<?> clazz;
            if (!inited) {
                block2: for (clazz = object.getClass(); clazz != null && accessorField == null; clazz = clazz.getSuperclass()) {
                    object2 = clazz.getDeclaredFields();
                    n2 = ((Field[])object2).length;
                    for (n = 0; n < n2; ++n) {
                        accessibleObject = object2[n];
                        if (!Modifier.isStatic(((Field)accessibleObject).getModifiers()) || !((Field)accessibleObject).getName().equals("DATA_PLAYER_MODE_CUSTOMISATION")) continue;
                        ((Field)accessibleObject).setAccessible(true);
                        accessorField = accessibleObject;
                        continue block2;
                    }
                }
                block4: for (clazz = object.getClass(); clazz != null && getEntityData == null; clazz = clazz.getSuperclass()) {
                    object2 = clazz.getDeclaredMethods();
                    n2 = ((AccessibleObject[])object2).length;
                    for (n = 0; n < n2; ++n) {
                        accessibleObject = object2[n];
                        if (!((Method)accessibleObject).getName().equals("getEntityData") || ((Method)accessibleObject).getParameterCount() != 0) continue;
                        ((Method)accessibleObject).setAccessible(true);
                        getEntityData = accessibleObject;
                        continue block4;
                    }
                }
                inited = true;
                if (accessorField == null || getEntityData == null) {
                    readBroken = true;
                    return false;
                }
            }
            clazz = getEntityData.invoke(object, new Object[0]);
            if (dataGet == null) {
                object2 = clazz.getClass().getMethods();
                n2 = ((AccessibleObject[])object2).length;
                for (n = 0; n < n2; ++n) {
                    accessibleObject = object2[n];
                    if (!((Method)accessibleObject).getName().equals("get") || ((Method)accessibleObject).getParameterCount() != 1) continue;
                    dataGet = accessibleObject;
                    break;
                }
                if (dataGet == null) {
                    readBroken = true;
                    return false;
                }
            }
            return (object2 = dataGet.invoke(clazz, accessorField.get(null))) instanceof Byte && ((by = (Byte)object2) & 0x80) != 0;
        }
        catch (Throwable throwable) {
            readBroken = true;
            return false;
        }
    }

    static {
        modelIdx = -1;
    }
}

